%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%
%% Copyright 2023 Jonatan Mac Intyre
%%
%% Licensed under the Apache License, Version 2.0 (the "License");
%% you may not use this file except in compliance with the License.
%% You may obtain a copy of the License at
%%
%%      http://www.apache.org/licenses/LICENSE-2.0
%%
%% Unless required by applicable law or agreed to in writing, software
%% distributed under the License is distributed on an "AS IS" BASIS,
%% WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
%% See the License for the specific language governing permissions and
%% limitations under the License.
%%
%% Code description:
%%
%% The present code allows to track small object in a video, determine their
%% position as a function of time. It computes the velocity of each object.
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Particle Tracking 

clear all 
clearvars -global
addpath(genpath(pwd))
clc 

%% Define parameters 

file = 'lead2.3_S0001.avi' ; 

% Select the frame rate to analyze and the step
FirstFrame = 1 ; 
LastFrame = 200 ; 
FrameRate = 5 ; 

% Show video with particle tracking: 'yes' or 'no'
showVideo = 'yes' ; 

% Convertion factors
timeScale = 0.03 ; % time/frame
spaceScale = 10 ; % micrometer/pxls

%% Run code

[Particles,Particle_Velocity,Settings] = run_analysis(file,FirstFrame,LastFrame,FrameRate,showVideo,timeScale,spaceScale) ; 

clear file FirstFrame LastFrame FrameRate spaceScale timeScale showVideo